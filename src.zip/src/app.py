import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.title("💰 Personal Expense Tracker Dashboard")

# CSV UPLOAD OPTION
uploaded_file = st.file_uploader(
    "Upload Expense CSV",
    type=["csv"]
)

if uploaded_file is not None:

    df = pd.read_csv(uploaded_file)

else:
    df = pd.read_csv("data/cleaned_expenses.csv")

# SHOW DATA
st.subheader("Expense Dataset")

st.dataframe(df.head())

# TOTAL SPENDING
total_spending = df["amount"].sum()

st.metric(
    "Total Spending",
    f"₹{total_spending:.2f}"
)

# CATEGORY ANALYSIS
category_analysis = (
    df.groupby("category")["amount"]
    .sum()
)

st.subheader("Category-wise Analysis")

fig1, ax1 = plt.subplots()

category_analysis.plot(
    kind="bar",
    ax=ax1
)

st.pyplot(fig1)

# MONTHLY ANALYSIS
monthly_analysis = (
    df.groupby("month")["amount"]
    .sum()
)

st.subheader("Monthly Spending Trend")

fig2, ax2 = plt.subplots()

monthly_analysis.plot(
    marker="o",
    ax=ax2
)

st.pyplot(fig2)

# PAYMENT ANALYSIS
payment_analysis = (
    df.groupby("payment_method")["amount"]
    .sum()
)

st.subheader("Payment Method Analysis")

fig3, ax3 = plt.subplots()

payment_analysis.plot(
    kind="pie",
    autopct="%1.1f%%",
    ax=ax3
)

ax3.set_ylabel("")

st.pyplot(fig3)

# BUDGET TRACKER
monthly_budget = 25000

monthly_spending = monthly_analysis.sum()

st.subheader("Budget Tracking")

st.write(f"Monthly Budget: ₹{monthly_budget}")

st.write(f"Current Spending: ₹{monthly_spending:.2f}")

if monthly_spending > monthly_budget:

    st.error("⚠ Budget Exceeded!")

else:

    st.success("✅ Within Budget")