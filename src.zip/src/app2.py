import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# =====================================================
# PAGE CONFIG
# =====================================================

st.set_page_config(
    page_title="Expense Tracker Dashboard",
    page_icon="💰",
    layout="wide"
)

# =====================================================
# CUSTOM CSS
# =====================================================

st.markdown("""
<style>

body {
    background-color: #f4f9ff;
}

.main {
    background-color: #f4f9ff;
}

.block-container {
    padding-top: 1rem;
    padding-bottom: 1rem;
}

h1, h2, h3 {
    color: #0077b6;
    font-weight: bold;
}

div[data-testid="metric-container"] {
    background-color: white;
    border: 1px solid #dceeff;
    padding: 15px;
    border-radius: 12px;
    box-shadow: 0px 2px 6px rgba(0,0,0,0.08);
}

div[data-testid="stSidebar"] {
    background-color: #0077b6;
}

div[data-testid="stSidebar"] * {
    color: white;
}

.chart-box {
    background-color: white;
    padding: 10px;
    border-radius: 12px;
    box-shadow: 0px 2px 8px rgba(0,0,0,0.08);
}

</style>
""", unsafe_allow_html=True)

# =====================================================
# TITLE
# =====================================================

st.title("💰 Personal Expense Tracker Dashboard")

st.markdown(
    "Interactive finance analytics dashboard using Python, Pandas, SQLite, and Streamlit."
)

# =====================================================
# SIDEBAR
# =====================================================

st.sidebar.header("⚙ Dashboard Filters")

uploaded_file = st.sidebar.file_uploader(
    "Upload Expense CSV",
    type=["csv"]
)

# =====================================================
# LOAD DATA
# =====================================================

try:

    if uploaded_file is not None:
        df = pd.read_csv(uploaded_file)

    else:
        df = pd.read_csv("C:\\Users\\NIKHIL\\Downloads\\vscode.python\\data\\Personal-Expense-Tracker-Visualization\\data\\cleaned_expenses.csv")

except FileNotFoundError:

    st.error("❌ cleaned_expenses.csv not found.")

    st.stop()

# =====================================================
# DATA CLEANING
# =====================================================

df.dropna(inplace=True)

df["date"] = pd.to_datetime(df["date"])

if "month" not in df.columns:
    df["month"] = df["date"].dt.strftime("%Y-%m")

# =====================================================
# SIDEBAR FILTERS
# =====================================================

selected_categories = st.sidebar.multiselect(
    "Select Categories",
    options=df["category"].unique(),
    default=df["category"].unique()
)

selected_payment = st.sidebar.multiselect(
    "Select Payment Methods",
    options=df["payment_method"].unique(),
    default=df["payment_method"].unique()
)

monthly_budget = st.sidebar.slider(
    "Monthly Budget",
    min_value=5000,
    max_value=100000,
    value=25000,
    step=1000
)

# =====================================================
# FILTER DATA
# =====================================================

filtered_df = df[
    (df["category"].isin(selected_categories)) &
    (df["payment_method"].isin(selected_payment))
]

# =====================================================
# KPI CALCULATIONS
# =====================================================

total_spending = filtered_df["amount"].sum()

average_daily_spending = (
    filtered_df.groupby("date")["amount"]
    .sum()
    .mean()
)

top_category = (
    filtered_df.groupby("category")["amount"]
    .sum()
    .idxmax()
)

top_category_amount = (
    filtered_df.groupby("category")["amount"]
    .sum()
    .max()
)

# =====================================================
# KPI CARDS
# =====================================================

col1, col2, col3, col4 = st.columns(4)

col1.metric(
    "💸 Total Spending",
    f"₹{total_spending:,.0f}"
)

col2.metric(
    "📅 Avg Daily",
    f"₹{average_daily_spending:,.0f}"
)

col3.metric(
    "🔥 Top Category",
    top_category
)

col4.metric(
    "🏆 Top Category Spend",
    f"₹{top_category_amount:,.0f}"
)

# =====================================================
# BUDGET TRACKER
# =====================================================

st.subheader("💰 Budget Status")

if total_spending > monthly_budget:

    st.error(
        f"⚠ Budget Exceeded! Current: ₹{total_spending:,.0f}"
    )

else:

    st.success(
        f"✅ Budget Safe! Current: ₹{total_spending:,.0f}"
    )

# =====================================================
# ANALYTICS
# =====================================================

category_analysis = (
    filtered_df.groupby("category")["amount"]
    .sum()
    .sort_values(ascending=False)
)

monthly_analysis = (
    filtered_df.groupby("month")["amount"]
    .sum()
)

payment_analysis = (
    filtered_df.groupby("payment_method")["amount"]
    .sum()
)

daily_analysis = (
    filtered_df.groupby("date")["amount"]
    .sum()
)

# =====================================================
# SMALL POWER BI STYLE CHARTS
# =====================================================

col_left, col_right = st.columns(2)

# =====================================================
# CATEGORY BAR CHART
# =====================================================

with col_left:

    st.subheader("📊 Category Analysis")

    fig1, ax1 = plt.subplots(figsize=(5, 3))

    sns.barplot(
        x=category_analysis.index,
        y=category_analysis.values,
        ax=ax1
    )

    plt.xticks(rotation=30, fontsize=8)

    plt.yticks(fontsize=8)

    plt.xlabel("")

    plt.ylabel("")

    plt.tight_layout()

    st.pyplot(fig1)

# =====================================================
# PAYMENT PIE CHART
# =====================================================

with col_right:

    st.subheader("💳 Payment Analysis")

    fig2, ax2 = plt.subplots(figsize=(4, 4))

    payment_analysis.plot(
        kind="pie",
        autopct="%1.1f%%",
        ax=ax2
    )

    ax2.set_ylabel("")

    plt.tight_layout()

    st.pyplot(fig2)

# =====================================================
# SECOND ROW
# =====================================================

col_left2, col_right2 = st.columns(2)

# =====================================================
# MONTHLY TREND
# =====================================================

with col_left2:

    st.subheader("📈 Monthly Trend")

    fig3, ax3 = plt.subplots(figsize=(5, 3))

    monthly_analysis.plot(
        marker="o",
        linewidth=2,
        ax=ax3
    )

    plt.xticks(rotation=20, fontsize=8)

    plt.yticks(fontsize=8)

    plt.xlabel("")

    plt.ylabel("")

    plt.tight_layout()

    st.pyplot(fig3)

# =====================================================
# DAILY TREND
# =====================================================

with col_right2:

    st.subheader("📅 Daily Spending")

    fig4, ax4 = plt.subplots(figsize=(5, 3))

    daily_analysis.plot(
        linewidth=2,
        ax=ax4
    )

    plt.xticks(fontsize=7)

    plt.yticks(fontsize=8)

    plt.xlabel("")

    plt.ylabel("")

    plt.tight_layout()

    st.pyplot(fig4)

# =====================================================
# DATASET PREVIEW
# =====================================================

st.subheader("🗂 Expense Dataset")

st.dataframe(
    filtered_df.head(15),
    use_container_width=True
)

# =====================================================
# DOWNLOAD BUTTON
# =====================================================

csv = filtered_df.to_csv(index=False)

st.download_button(
    label="⬇ Download Filtered Data",
    data=csv,
    file_name="filtered_expenses.csv",
    mime="text/csv"
)

# =====================================================
# FOOTER
# =====================================================

st.markdown("---")

st.markdown(
    """
    <center>
    <h4 style='color:#0077b6'>
    Personal Expense Tracker Dashboard
    </h4>
    </center>
    """,
    unsafe_allow_html=True
)