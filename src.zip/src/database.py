import pandas as pd
import sqlite3
import os

os.makedirs("database", exist_ok=True)

df = pd.read_csv("data/cleaned_expenses.csv")

conn = sqlite3.connect("database/expenses.db")

df.to_sql(
    "expenses",
    conn,
    if_exists="replace",
    index=False
)

print("SQLite database created successfully!")

conn.close()